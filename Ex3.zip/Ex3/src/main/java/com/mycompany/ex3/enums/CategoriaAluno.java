/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex3.enums;

/**
 *
 * @author CT-01
 */
public enum CategoriaAluno {
    ATIVO,
    EX_ALUNO,
    AGUARDANDO_MATRICULA,
    BLOQUEADO
}
