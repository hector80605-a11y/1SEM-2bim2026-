/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex3.model;

import com.mycompany.ex3.enums.CategoriaAluno;

/**
 *
 * @author CT-01
 */
public class Aluno {
    private String telefone;
    private String endereco;
    
    private Mae mae;
    private Pai pai;
    
    private CategoriaAluno categoria;

    public Aluno(String telefone, String endereco, Mae mae, Pai pai, CategoriaAluno categoria) {
        this.telefone = telefone;
        this.endereco = endereco;
        this.mae = mae;
        this.pai = pai;
        this.categoria = categoria;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Mae getMae() {
        return mae;
    }

    public void setMae(Mae mae) {
        this.mae = mae;
    }

    public Pai getPai() {
        return pai;
    }

    public void setPai(Pai pai) {
        this.pai = pai;
    }

    public CategoriaAluno getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaAluno categoria) {
        this.categoria = categoria;
    }
    
    
}
