/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ex3;

/**
 *
 * @author CT-01
 */
public class Ex3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
