/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex3.model;

/**
 *
 * @author CT-01
 */
public class Professores {
    private int agencia;
    private int conta;
    private double horaAula;

    public Professores(int agencia, int conta, double horaAula) {
        this.agencia = agencia;
        this.conta = conta;
        this.horaAula = horaAula;
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public int getConta() {
        return conta;
    }

    public void setConta(int conta) {
        this.conta = conta;
    }

    public double getHoraAula() {
        return horaAula;
    }

    public void setHoraAula(double horaAula) {
        this.horaAula = horaAula;
    }
    
    
}
