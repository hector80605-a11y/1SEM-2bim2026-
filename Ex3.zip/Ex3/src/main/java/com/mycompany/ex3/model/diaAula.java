/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex3.model;

/**
 *
 * @author CT-01
 */
public class diaAula {
    private String nome;
    private String quantidadeHoras;

    public diaAula(String nome, String quantidadeHoras) {
        this.nome = nome;
        this.quantidadeHoras = quantidadeHoras;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQuantidadeHoras() {
        return quantidadeHoras;
    }

    public void setQuantidadeHoras(String quantidadeHoras) {
        this.quantidadeHoras = quantidadeHoras;
    }
    
}
