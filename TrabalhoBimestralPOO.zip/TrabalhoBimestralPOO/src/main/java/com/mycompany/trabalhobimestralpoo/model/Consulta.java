/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhobimestralpoo.model;

import com.mycompany.trabalhobimestralpoo.model.Animal;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author hector80605
 */
public class Consulta {

    private final LocalDate data;
    private final LocalTime horario;
    private final Veterinario veterinario;
    private final Animal animal;

   
    private double valor;

    public Consulta(LocalDate data, LocalTime horario, Animal animal, Veterinario veterinario) {
        this.data = data;
        this.horario = horario;
        this.animal = animal;
        this.veterinario = veterinario;
        
    }
    
     public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    

    public Animal getAnimal() {return animal;}
    public Veterinario getVeterinario(){return veterinario;}
    public LocalDate getData() {return data;}
    public LocalTime getHorario() {return horario;}

}