/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhobimestralpoo.model;

/**
 *
 * @author CT-01
 */
public class Recepcionista extends Funcionario {

    public enum Turno {
        MANHA, TARDE, NOITE
    };
    private final Turno turno;

    public Recepcionista(String nome, String cpf, double salarioBase, Turno turno) {

        super(nome, cpf, salarioBase);
        this.turno = turno;
    }
    
    public Turno getTurno(){
        return turno;
    }
}
