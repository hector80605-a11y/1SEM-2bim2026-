/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhobimestralpoo.model;

import com.mycompany.trabalhoBIM.model.Endereco;
import java.util.ArrayList;
/**
 *
 * @author hector80605
 */
public class Tutor{
    private String nome;
    private Endereco endereco;
    
    ArrayList<Animal> animais = new ArrayList<>();

    public Tutor(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public ArrayList<Animal> getAnimais() {
        return animais;
    }

    public void setAnimais(ArrayList<Animal> animais) {
        this.animais = animais;
    }

    @Override
    public String toString() {
        return "Tutor{" + "nome=" + nome + ", endereco=" + endereco + ", animais=" + animais + '}';
    }
    
    public void relatorio(){
    for (Animal animal : animais){
        for(Consulta consulta : animal.getConsultas()){
            System.out.println(""
                    + "Animal: " + animal.getNome()+
                    "Consulta" + consulta.getData()+
                    "Veterinário" + consulta.getVeterinario()+
                    "Valor: " + consulta.getValor());
        }
    }
  }
    
}
