/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhobimestralpoo.model;

/**
 *
 * @author CT-01
 */
public class Funcionario {
    private String nome;
    private String cpf;
    private double salarioBase;
    
    
    public Funcionario(String nome, String cpf, double salarioBase){
        this.nome = nome;
        this.cpf = cpf;
        this.salarioBase = salarioBase;
    }
    
    
    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }


    public double getSalarioBase() {
        return salarioBase;
    }

    
}
