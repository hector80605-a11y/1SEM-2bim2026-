/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhobimestralpoo.model;

/**
 *
 * @author CT-01
 */
public class Veterinario extends Funcionario{
    private String crmv;
    public enum Especialidade{CLINICA_GERAL, DERMATOLOGIA, ORTOPEDIA};
    private Especialidade especialidade;
    
     public Veterinario(String nome, String cpf, double salarioBase, String crmv, Especialidade especialidade) {
        
        super(nome, cpf, salarioBase); 
        this.crmv = crmv;
        this.especialidade = especialidade;
    }
     
     public Especialidade getEspecialidade(){
         return especialidade;
     }
    
}

