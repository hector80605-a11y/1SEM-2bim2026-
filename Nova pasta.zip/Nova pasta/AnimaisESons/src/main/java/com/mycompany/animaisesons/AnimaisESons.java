/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.animaisesons;

import com.mycompany.animaisesons.model.Animal;
import com.mycompany.animaisesons.model.Cachorro;
import com.mycompany.animaisesons.model.Passaro;
import com.mycompany.animaisesons.model.Peixe;
import java.util.ArrayList;

/**
 *
 * @author hector80605
 */
public class AnimaisESons {

    public static void main(String[] args) {
        ArrayList <Animal> animais = new ArrayList<>();
        animais.add(new  Cachorro("Aldair"));
        animais.add(new Passaro("Jandira"));
        animais.add(new Peixe("Cenoura"));
        
        for (Animal contadorAnimal : animais){
            contadorAnimal.emitirSom();
            contadorAnimal.mover();
            contadorAnimal.dormir();
        }
    }
}
