/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.animaisesons.model;

/**
 *
 * @author hector80605
 */
public class Passaro extends Animal{

    public Passaro(String nome) {
        super(nome);
    }
    
    public void  emitirSom(){
        System.out.println("PIUPIUIU");
    }
    
    public void mover(){
        System.out.println("Voar");
    }
}
