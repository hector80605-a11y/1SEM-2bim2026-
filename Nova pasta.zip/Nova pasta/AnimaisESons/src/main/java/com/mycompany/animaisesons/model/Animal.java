/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.animaisesons.model;

/**
 *
 * @author hector80605
 */
public abstract class Animal {
    String nome;

    public Animal(String nome) {
        this.nome = nome;
    }
    
    public abstract void emitirSom();
    public abstract void mover();
    
    public void dormir(){
        System.out.println(nome + " está dormindo.");
    }
}
