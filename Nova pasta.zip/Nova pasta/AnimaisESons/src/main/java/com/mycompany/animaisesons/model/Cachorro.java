/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.animaisesons.model;

/**
 *
 * @author hector80605
 */
public class Cachorro extends Animal{

    public Cachorro(String nome) {
        super(nome);
    }
    
    @Override
    public void emitirSom(){
        System.out.println("AAAAUAUAUAU");
    }
    
    @Override
    public void mover(){
        System.out.println("Correr");
    }
}
