/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadepagamentos.model;

/**
 *
 * @author hector80605
 */
public class PagamentoCartao extends Pagamento{
    int numeroCartao;
    double limiteDisponivel;

    public PagamentoCartao(int numeroCartao, double limiteDisponivel, double valor) {
        super(valor);
        this.numeroCartao = numeroCartao;
        this.limiteDisponivel = limiteDisponivel;
    }
    
    public boolean processarPagamento(){
        return valor <= limiteDisponivel;
    }
    
    public String tipoPagamento(){
        return
        "O tipo de  pagamento é cartão. ";
    }
    
    
    
}
