/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemadepagamentos;

/**
 *
 * @author hector80605
 */
public class SistemaDePagamentos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
