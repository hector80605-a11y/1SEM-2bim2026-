/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadepagamentos.model;

/**
 *
 * @author hector80605
 */
public abstract class Pagamento {
    double valor;

    public Pagamento(double valor) {
        this.valor = valor;
    }
    
    public abstract boolean processarPagamento();
    public abstract String tipoPagamento();
    public void  exibirComprovante(){
        System.out.println("O valor do pagamento é: " + valor);
        System.out.println("O tipo do pagamento é: " + tipoPagamento());
    }
}   
