/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadepagamentos.model;

/**
 *
 * @author hector80605
 */
public class PagamentoPix extends Pagamento{
    String chavePix;

    public PagamentoPix(String chavePix, double valor) {
        super(valor);
        this.chavePix = chavePix;
    }

    
    
    @Override
    public boolean processarPagamento(){
        return true;
    }
    
    
    @Override
    public String tipoPagamento(){
        return
        "O tipo de pagamento é pix";
    }
    
    @Override
    public void exibirComprovante(){
        super.exibirComprovante();
        System.out.println("Chave Pix:" + chavePix);
    }
}
