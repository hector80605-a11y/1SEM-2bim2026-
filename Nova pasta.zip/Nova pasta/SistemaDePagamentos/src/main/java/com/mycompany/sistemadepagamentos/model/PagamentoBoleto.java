/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadepagamentos.model;

/**
 *
 * @author hector80605
 */
public class PagamentoBoleto extends Pagamento{
    String dataVenciento;
    boolean dentroDoVencimento;

    public PagamentoBoleto(String dataVenciento, double valor) {
        super(valor);
        this.dataVenciento = dataVenciento;
        this.dentroDoVencimento  = dentroDoVencimento;
    }
    
    @Override
    public boolean processarPagamento(){
        return dentroDoVencimento;
    }
    @Override
    public String tipoPagamento(){
        return "Boleto";
    }
    
}
