/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1.model;
/**
 *
 * @author hector80605
 */
public class Circulo extends Forma{
    double raio;

    public Circulo(double raio) {
        this.raio = raio;
    }
    
    @Override
    public double calcularArea(){
        System.out.println("A area do circulo é: ");
        return 3.14 * raio * raio;
    }
}
