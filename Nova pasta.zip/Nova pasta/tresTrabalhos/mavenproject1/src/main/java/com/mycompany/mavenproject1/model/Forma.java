/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1.model;

/**
 *
 * @author hector80605
 */
public abstract class Forma {
    public abstract double calcularArea();
    
    public void exibirArea(){
        System.out.println("A area é: " + calcularArea());
    }
}
