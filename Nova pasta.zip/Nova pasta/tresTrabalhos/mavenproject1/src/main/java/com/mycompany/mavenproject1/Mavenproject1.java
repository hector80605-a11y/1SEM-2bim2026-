/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

import com.mycompany.mavenproject1.model.Circulo;
import com.mycompany.mavenproject1.model.Forma;
import com.mycompany.mavenproject1.model.Retangulo;
import com.mycompany.mavenproject1.model.Triangulo;
import java.util.ArrayList;

/**
 *
 * @author hector80605
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        ArrayList <Forma> formas = new ArrayList<>();
        formas.add(new Circulo(5));
        formas.add(new Retangulo(10, 5));
        formas.add(new Triangulo(5, 5));
        
        for(Forma forma : formas){
            forma.exibirArea();
        }
        
        
    }
}
