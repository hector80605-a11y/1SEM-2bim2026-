/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pratica.utils;

import com.mycompany.pratica.model.Diretor;
import com.mycompany.pratica.model.Funcionario;
import com.mycompany.pratica.model.Gerente;

/**
 *
 * @author hector80605
 */
public class CalculadoraBonus {
    public void calcular(Funcionario funcionario){
    Double salarioComBonus = 1.0;
    
    if (funcionario instanceof Gerente){
        salarioComBonus = funcionario.getSalario() * 1.20;
    }
    if (funcionario instanceof Diretor){
        salarioComBonus = funcionario.getSalario() *1.5; 
    }
    
    
        System.out.println("Salario do funcionário " + funcionario.getNome() + " é " + salarioComBonus);
    }
}
