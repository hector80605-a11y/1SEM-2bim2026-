/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pratica;

import com.mycompany.pratica.model.Diretor;
import com.mycompany.pratica.model.Funcionario;
import com.mycompany.pratica.model.Gerente;
import com.mycompany.pratica.utils.CalculadoraBonus;

/**
 *
 * @author hector80605
 */
public class Pratica {

    public static void main(String[] args) {
        Funcionario funcionario = new Funcionario();
        funcionario.setId(1);
        funcionario.setNome("Aldair");
        funcionario.setSalario(2000.0);
        
        Gerente gerente = new Gerente();
        gerente.setId(1);
        gerente.setNome("Geroncio");
        gerente.setSalario(3000.0);
        
        Diretor diretor = new Diretor();
        diretor.setId(1);
        diretor.setNome("Alcir");
        diretor.setSalario(3900.0);
        
        CalculadoraBonus calculadoraBonus = new CalculadoraBonus();
        calculadoraBonus.calcular(funcionario);
        calculadoraBonus.calcular(gerente);
        calculadoraBonus.calcular(diretor);
        
        System.out.println("Salario dos funcionários: " +
                funcionario.getNome() + "é" + salarioComBonus);
        
        
    }
}
