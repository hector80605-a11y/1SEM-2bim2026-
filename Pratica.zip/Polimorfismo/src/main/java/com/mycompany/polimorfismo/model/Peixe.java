/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfismo.model;

/**
 *
 * @author hector80605
 */
public class Peixe extends Animal {
    private String tipoAgua;

    public String getTipoAgua() {
        return tipoAgua;
    }

    public void setTipoAgua(String tipoAgua) {
        this.tipoAgua = tipoAgua;
    }
    
    public void respirar(){
        System.out.println("Peixe respirando no fundo do oceano");
    }
}
