/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfismo.model;

/**
 *
 * @author hector80605
 */
public class Respirador {
    public void executarRespiracao(Animal animal){
        animal.respirar();
        
        if (animal instanceof Cachorro){
            System.out.println("CACHORRO");
        }
        if(animal instanceof Peixe){
            System.out.println("PEXE");
        }
    }
}
