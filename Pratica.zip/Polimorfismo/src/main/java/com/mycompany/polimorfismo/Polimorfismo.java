/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.polimorfismo;

import com.mycompany.polimorfismo.model.Animal;
import com.mycompany.polimorfismo.model.Cachorro;
import com.mycompany.polimorfismo.model.Peixe;
import com.mycompany.polimorfismo.model.Respirador;

/**
 *
 * @author hector80605
 */
public class Polimorfismo {

    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro();
        cachorro. setId(1);
        cachorro. setNome("Hunter");
        cachorro.setPelagem("Curto");
        
        Peixe peixe = new Peixe();
        peixe.setId(2);
        peixe.setNome("Nemo");
        peixe.setTipoAgua("Salgada");
        
        Animal animal = new Animal();
        animal.setId(3);
        animal.setNome("Fulano");
        animal.setPeso(8);
        
        Respirador respirador = new Respirador();
        respirador.executarRespiracao(cachorro);
        respirador.executarRespiracao(peixe);
    }
}
