/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfismo.model;

/**
 *
 * @author hector80605
 */
public class Cachorro extends Animal  {
    private String pelagem;

    public String getPelagem() {
        return pelagem;
    }

    public void setPelagem(String pelagem) {
        this.pelagem = pelagem;
    }
    
    @Override
    public void respirar(){
        super.respirar();
        System.out.println("Cachorro respirando o ar puro da floresta");
    }
}
