/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ex4;

import com.mycompany.ex4.model.Pessoa;

/**
 *
 * @author CT-01
 */
public class Ex4 {

    public static void main(String[] args) {
        Pessoa pessoa1 = new Pessoa("aaaaa", 20, a, a );
        Pessoa pessoa2 = new Pessoa("bbbbb", 19, , );
        Pessoa pessoa3 = new Pessoa("gggg", 21, , );
    }
}
