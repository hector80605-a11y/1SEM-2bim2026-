/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1.model;

/**
 *
 * @author CT-01
 */
public abstract class Pagamento {
   public String getTipo;
}
