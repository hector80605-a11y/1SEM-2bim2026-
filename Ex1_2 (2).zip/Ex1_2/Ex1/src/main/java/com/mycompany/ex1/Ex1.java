/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ex1;

import com.mycompany.ex1.model.FormaPagamento;
import com.mycompany.ex1.model.Item;
import com.mycompany.ex1.model.Pagamento;
import com.mycompany.ex1.model.Pedido;
import com.mycompany.ex1.model.Produto;

/**
 *
 * @author hector80605
 */
public class Ex1 {

    public static void main(String[] args) {
        Produto macarrão = new Produto("macarrão", 85, 10);
        Produto batata = new Produto("batata", 10, 100);
        
        Item item1 = new Item(macarrão ,2);
        Item item2 = new Item(batata, 10);
        
        Pedido pedido1 = new Pedido();
        pedido1.adicionarItem(item1);
        pedido1.adicionarItem(item2);
            
        FormaPagamento pagamento1 = new FormaPagamento();
    }
}
