/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1.model;
import java.util.ArrayList;
/**
 *
 * @author hector80605
 */
public class Pedido {
    ArrayList<Item> itens = new ArrayList<Item>();
    private Pagamento formaPagamento;

    public ArrayList<Item> getItens() {
        return itens;
    }

    public void setItens(ArrayList<Item> itens) {
        this.itens = itens;
    }

    public Pagamento getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(Pagamento formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    @Override
    public String toString() {
        return "Pedido{" + "itens=" + itens + ", formaPagamento=" + formaPagamento + '}';
    }
    
    
    public Pedido(){
        itens = new ArrayList<>();
    }
    
    public void adicionarItem(Item item){
    itens.add(item);
    }
    
    public double calcularTotal(){
    double total = 0;
    
    for (Item item : itens){
    total += item.subtotal();
    }
    
    return total;
    }
    
    public void valorCompra(){
        System.out.println("PRODUTOS:==============");
        for(Item item : itens){
            System.out.println(item.getProduto().getNome() + "x" + item.getQuantidade() + "= R$" + item.subtotal());
        }
        
        System.out.println("Total:" + calcularTotal());
        System.out.println("Pagamento: " + formaPagamento.getFormaPagamento());
    }
}
