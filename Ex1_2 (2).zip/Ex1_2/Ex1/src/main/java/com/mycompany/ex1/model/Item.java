/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1.model;

/**
 *
 * @author hector80605
 */
public class Item {
    private Produto produto;
    private Integer quantidade;
    
    public Item(Produto produto, Integer quantidade){
    this.produto = produto;
    this.quantidade = quantidade;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "Item{" + "produto=" + produto + ", quantidade=" + quantidade + '}';
    }
    
    public double subtotal(){
    return produto.getPreco() * quantidade;
    }
}
