/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex2.model;

import java.util.ArrayList;

/**
 *
 * @author CT-01
 */
public class Aluno {
    private String nome;
    ArrayList<Materia> materias = new ArrayList<>();
    
    public Aluno (String nome){
    this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Materia> getMaterias() {
        return materias;
    }

    public void setMaterias(ArrayList<Materia> materias) {
        this.materias = materias;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", materias=" + materias + '}';
    }
}
