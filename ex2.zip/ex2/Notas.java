/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex2.model;

/**
 *
 * @author CT-01
 */
public class Notas {
    private double notaTrabalho;
    private double notaProva;
    
    public Notas (double notaTrabalho, double notaProva){
    this.notaProva = notaProva;
    this.notaTrabalho = notaTrabalho;
    }

    public double getNotaTrabalho() {
        return notaTrabalho;
    }

    public void setNotaTrabalho(double notaTrabalho) {
        this.notaTrabalho = notaTrabalho;
    }

    public double getNotaProva() {
        return notaProva;
    }

    public void setNotaProva(double notaProva) {
        this.notaProva = notaProva;
    }

    @Override
    public String toString() {
        return "Notas{" + "notaTrabalho=" + notaTrabalho + ", notaProva=" + notaProva + '}';
    }
}
