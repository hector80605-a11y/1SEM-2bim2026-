/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex2.model;

/**
 *
 * @author CT-01
 */
public class Materia {
    private String nome;
    Notas nota[] = new Notas[4];
    
    public Materia (String nome){
    this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Notas[] getNota() {
        return nota;
    }

    public void setNota(Notas[] nota) {
        this.nota = nota;
    }    
}
