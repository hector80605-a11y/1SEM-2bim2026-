/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ex2;

import com.mycompany.ex2.model.Aluno;
import com.mycompany.ex2.model.Materia;
import com.mycompany.ex2.model.Notas;

/**
 *
 * @author CT-01
 */
public class Ex2 {

    public static void main(String[] args) {
        Aluno aluno = new Aluno("hector");
        Materia matematica = new Materia("Portugês");
        
        Materia.nota[0] = new Notas (10, 20);
    }
}
