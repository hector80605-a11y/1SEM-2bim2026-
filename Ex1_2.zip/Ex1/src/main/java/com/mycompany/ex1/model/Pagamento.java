/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1.model;

/**
 *
 * @author CT-01
 */
public class Pagamento {
    private FormaPagamento formaPagamento;
    private Integer valorCompra;

    public FormaPagamento getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(FormaPagamento formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Integer getValorCompra() {
        return valorCompra;
    }

    public void setValorCompra(Integer valorCompra) {
        this.valorCompra = valorCompra;
    }

    @Override
    public String toString() {
        return "Pagamento{" + "formaPagamento=" + formaPagamento + ", valorCompra=" + valorCompra + '}';
    }
    
}
