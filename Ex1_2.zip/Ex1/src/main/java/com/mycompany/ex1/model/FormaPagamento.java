/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex1.model;

/**
 *
 * @author CT-01
 */
public class FormaPagamento {
    private String cheque;
    private String dinheiro;
    private String pix;

    public String getCheque() {
        return cheque;
    }

    public void setCheque(String cheque) {
        this.cheque = cheque;
    }

    public String getDinheiro() {
        return dinheiro;
    }

    public void setDinheiro(String dinheiro) {
        this.dinheiro = dinheiro;
    }

    public String getPix() {
        return pix;
    }

    public void setPix(String pix) {
        this.pix = pix;
    }

    @Override
    public String toString() {
        return "FormaPagamento{" + "cheque=" + cheque + ", dinheiro=" + dinheiro + ", pix=" + pix + '}';
    }
    
    
}
